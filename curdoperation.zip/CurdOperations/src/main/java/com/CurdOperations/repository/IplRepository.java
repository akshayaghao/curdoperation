package com.CurdOperations.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CurdOperations.entity.IplTeam;

public interface IplRepository extends JpaRepository<IplTeam, Integer>{

}
