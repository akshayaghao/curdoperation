package com.CurdOperations.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.CurdOperations.entity.IplTeam;
public interface IplService {
public IplTeam insertdata(IplTeam iplTeam);

public List<IplTeam>getAllTeams();
public IplTeam updateTeam(int id,IplTeam iplTeam);
public void delete(int id);
}
